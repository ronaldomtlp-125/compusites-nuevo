package com.compusites;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompusitesApplicationTests {

	@Test
	void contextLoads() {
	}

}
